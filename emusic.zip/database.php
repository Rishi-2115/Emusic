<?php
$con=mysql_connect("localhost","root","") or die("could not connect ");
mysql_select_db("emusic",$con)  or die("Could connect to Database");
?>