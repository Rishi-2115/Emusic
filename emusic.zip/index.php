<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>index</title>
<style type="text/css">
<!--
body {
	background-image: url(images/banner4.jpg);
}
.style4 {
	font-size: 46px;
	font-weight: bold;
	color: #D45A8B;
	font-family: "Courier New", Courier, monospace;
}
.style8 {
	font-size: 26px;
	font-style: italic;
	color: #B63065;
}
.style9 {color: #A92C5E}
.style13 {
	color: #de6290;
	font-weight: bold;
	font-size: 20px;
}
.style15 {
	color: #d5d9d8;
	font-weight: bold;
	font-size: 18px;
}
input[type="text"]
{
    background: rgba(255, 255, 255, 0.5);
    border:none;
    outline: none;
}
input[type="password"]
{
    background: rgba(255, 255, 255, 0.5);
    border: none;
    outline: none;
}
input[type="submit"]  {
    background-color: rgba(196,202,236, 0.5);
    border: none;
    color: white;
    padding: 10px 100px;
    text-align: center;
    text-decoration: none;
    display: inline-block;
    font-size: 20px;
    margin: 4px 2px;
    cursor: pointer;
	font-weight:bold
}
input[type="submit"]:hover
{
  background-color: rgba(0,204,0, 0.9);
}

-->
</style>
<script type="text/javascript">
<!--
function MM_preloadImages() { //v3.0
  var d=document; if(d.images){ if(!d.MM_p) d.MM_p=new Array();
    var i,j=d.MM_p.length,a=MM_preloadImages.arguments; for(i=0; i<a.length; i++)
    if (a[i].indexOf("#")!=0){ d.MM_p[j]=new Image; d.MM_p[j++].src=a[i];}}
}
//-->
</script>
<script src="Scripts/AC_RunActiveContent.js" type="text/javascript"></script>
</head>

<body>
<table width="1024" border="0" align="center" cellpadding="0" cellspacing="0">
  <!--DWLayoutTable-->
  <tr>
    <td height="80" colspan="5" valign="top"><img src="images/title2.jpg" width="1024" height="80" /></td>
  </tr>
  <tr>
    <td width="5" height="13"></td>
    <td width="498"></td>
    <td width="4"></td>
    <td width="512"></td>
    <td width="5"></td>
  </tr>
  <tr>
    <td rowspan="4" valign="top" bgcolor="#d1d5d6"><!--DWLayoutEmptyCell-->&nbsp;</td>
    <td height="80" colspan="3" valign="top"><script type="text/javascript">
AC_FL_RunContent( 'codebase','http://download.macromedia.com/pub/shockwave/cabs/flash/swflash.cab#version=9,0,28,0','width','1014','height','80','src','images/bar2','quality','high','pluginspage','http://www.adobe.com/shockwave/download/download.cgi?P1_Prod_Version=ShockwaveFlash','movie','images/bar2' ); //end AC code
</script><noscript><object classid="clsid:D27CDB6E-AE6D-11cf-96B8-444553540000" codebase="http://download.macromedia.com/pub/shockwave/cabs/flash/swflash.cab#version=9,0,28,0" width="1014" height="80">
      <param name="movie" value="images/bar2.swf" />
      <param name="quality" value="high" />
      <embed src="images/bar2.swf" quality="high" pluginspage="http://www.adobe.com/shockwave/download/download.cgi?P1_Prod_Version=ShockwaveFlash" type="application/x-shockwave-flash" width="1014" height="80"></embed>
    </object></noscript></td>
    <td rowspan="4" valign="top" bgcolor="#d1d5d6"><!--DWLayoutEmptyCell-->&nbsp;</td>
  </tr>
  <tr>
    <td height="66">&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
  </tr>
  

  
  <tr>
    <td height="412" align="center" valign="middle" ><div align="center" class="style4">
      <p class="style9">Welcome to eMusic</p>
      <p align="center" class="style8"> Your one stop to listen to<br />
        your favourite songs and <br />
        shop for any music <br />
        instrument.</p>
    </div></td>
    <td valign="top" bgcolor="#d1d5d6"><!--DWLayoutEmptyCell-->&nbsp;</td>
    <td valign="top">
    <form action="<?php echo $_SERVER['PHP_SELF'] ?>" name="form1" method="post">
    <table width="100%" border="0" cellpadding="0" cellspacing="0" >
      <!--DWLayoutTable-->
      <tr>
        <td width="87" height="30">&nbsp;</td>
        <td colspan="2" align="center" valign="middle"><div align="center" style="background: rgba(100, 100, 100, 0.2);"><span class="style13">User Login</span></div></td>
        <td width="95">&nbsp;</td>
      </tr>
      <tr>
        <td height="60">&nbsp;</td>
        <td colspan="2" valign="top" style="background: rgba(100, 100, 100, 0.2);"><!--DWLayoutEmptyCell-->&nbsp;</td>
        <td>&nbsp;</td>
      </tr>
      <tr>
        <td height="30">&nbsp;</td>
        <td width="121" align="center" valign="middle" style="background: rgba(100, 100, 100, 0.2);"><span class="style15">Username : </span></td>
        <td width="209" align="center" valign="middle" style="background: rgba(100, 100, 100, 0.2);"><input type="text" name="username" required/></td>
        <td>&nbsp;</td>
      </tr>
      <tr>
        <td height="30">&nbsp;</td>
        <td align="center" valign="middle" style="background: rgba(100, 100, 100, 0.2);"><span class="style15">Password : </span></td>
        <td align="center" valign="middle" style="background: rgba(100, 100, 100, 0.2);"><input type="password" name="password" required/></td>
        <td>&nbsp;</td>
      </tr>
      <tr>
        <td height="20"></td>
        <td colspan="2" align="center" valign="middle" style="background: rgba(100, 100, 100, 0.2);">
        <?php
		session_start();
		if(isset($_POST['submit']))
		{
			include("database.php");
			$username=$_POST['username'];
			$password=$_POST['password'];
			
			$sql=mysql_query("select * from user where username='$username' and password='$password'");
			
			if(mysql_num_rows($sql)<1)
			{
				echo "<font color=#B63065><b>Invalid Username or Password</b></font>";
			}
			else
			{
				$_SESSION['username']=$username;
				header("location:login.php");
			}
		}
		?>        </td>
        <td></td>
      </tr>
      <tr>
        <td height="30"></td>
        <td colspan="2" align="center" valign="middle" style="background: rgba(100, 100, 100, 0.2);"><input type="submit" name="submit" value="login" /></td>
        <td></td>
      </tr>
      <tr>
        <td height="30"></td>
        <td colspan="2" align="center" valign="bottom" style="background: rgba(100, 100, 100, 0.2);"><span class="style15">New User ? <a href="signup.php" target="_self">SignUp</a> Free</span></td>
        <td></td>
      </tr>
      <tr>
        <td height="47"></td>
        <td colspan="2" valign="top" style="background: rgba(100, 100, 100, 0.2);"><!--DWLayoutEmptyCell-->&nbsp;</td>
        <td></td>
      </tr>
      <tr>
        <td height="105"></td>
        <td>&nbsp;</td>
        <td></td>
        <td></td>
      </tr>
    </table></form></td>
  </tr>
  <tr>
    <td height="102">&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
  </tr>
</table>
</body>
</html>